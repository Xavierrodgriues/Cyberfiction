Subject: <?= $Subject ?>
From: <?= $From ?>
To: <?= $To ?>
Cc:
Bcc:
Format: HTML

<p>Record status changed as follows:</p>

<p>
Table: <?= $Table ?><br>
Key value: <?= $Key ?><br>
Action: <?= $Action ?>
</p>
