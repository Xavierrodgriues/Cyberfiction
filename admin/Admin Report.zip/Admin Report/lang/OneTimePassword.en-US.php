Subject: Your One Time Password for Login
From: <?= $From ?>
To: <?= $To ?>
Cc:
Bcc:
Format: HTML

<p>Please use the following security code for the account <?= $Account ?>.<br>
Security code: <?= $Code ?></p>
<p>If this was not you, please contact the technical support.</p>
